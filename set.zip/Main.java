package set;

public class Main {

	public static void main(String[] args) throws Exception {

		System.out.println("A: utworzenie pustego zbioru o pojemności 7");
		Set<Integer> A = new Set<Integer>(7);
		System.out.println("A: " + A.toString());
		try {
			A.dodajElement(1);
			A.dodajElement(3);
		}
		catch (Exception e) {};
		try {
			A.dodajElement(3);
		}
		catch (Exception e) {};
		try {
			A.dodajElement(2);
			A.dodajElement(5);
			A.dodajElement(4);
			System.out.println("A: Dodanie kolejno elementów: 1, 3, 3, 2, 5, 4");
			System.out.println("A: " + A.toString());
			A.usunElement(3);
			System.out.println("A: usunElement(3)");
			System.out.println("A: " + A.toString());
		}
		catch (Exception e) {};
			
		Set<Integer> B = new Set<Integer>(5);
		try {	
			B.dodajElement(3);
			B.dodajElement(7);
			B.dodajElement(4);
			B.dodajElement(9);
			B.dodajElement(2);
			B.usunElement(4);
			System.out.println("B: " + B.toString());
		}
		catch (Exception e) {};
			
	
		System.out.println("A: dodajElementy(B)");
		A.dodajElementy(B);
		System.out.println("A: " + A.toString());
			
			
		Set<Integer> C = new Set<Integer>(5);
		try {
			C.dodajElement(3);
			C.dodajElement(6);
			C.dodajElement(5);
			C.dodajElement(1);
			C.dodajElement(8);
			System.out.println("C: " + C.toString());
		}
		catch (Exception e) {};
			
			
	
		System.out.println("A: odejmijElementy(C)");
		A.odejmijElementy(C);
		System.out.println("A: " + A.toString());
			
			
		Set<Integer> D = new Set<Integer>(5);
		try {
			D.dodajElement(1);
			D.dodajElement(5);
			D.dodajElement(4);
			D.dodajElement(9);
			D.dodajElement(11);
			System.out.println("D: " + D.toString());
		}
		catch (Exception e) {};
			
			
		System.out.println("A: przeciecie(D)");
		A.przeciecie(D);
		System.out.println("A: " + A.toString());
			
		
		System.out.println("E: utworzenie pustego zbioru o pojemności 1");
		Set<Integer> E = new Set<Integer>(1);
		System.out.println("E: " + E.toString());
		try {
			E.dodajElement(1);
			E.dodajElement(2);
		}
		catch (Exception e) {};
		System.out.println("E: Dodanie kolejno elementów: 1, 2 (test pojemności)");
		System.out.println("E: " + E.toString());
	}
}
