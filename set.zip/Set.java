package set;

public class Set<T extends Comparable<T>> {
	private int pojemnosc;
	private int rozmiar;
	private T[] set;
	
	@SuppressWarnings("unchecked")
	public Set(int pojemnosc) {
		this.pojemnosc = pojemnosc;
		rozmiar = 0;
		set = (T[]) new Comparable[pojemnosc];
	}
	
	public int getPojemnosc() { return pojemnosc; }
	public int getRozmiar() { return rozmiar; }
	public T getElement(int x) throws Exception {
		if (x < 0 || x >= rozmiar) throw new Exception("Indeks poza zakresem");
		return set[x];
	}
	
	//dodaje element of wskazanej wartości
	public void dodajElement(T element) throws Exception {
	    if (rozmiar == pojemnosc) {
	        throw new IndexOutOfBoundsException("Zbiór pełny");
	    }
	    
	    if (szukaj(element) != -1) {
	        throw new Exception("Element już istnieje");
	    }
	    
	    int i;
	    for (i = rozmiar - 1; i >= 0 && set[i].compareTo(element) > 0; i--) {
	        set[i + 1] = set[i];
	    }
	    set[i + 1] = element;
	    rozmiar++;
	}
	
	//zwraca indeks wskazanego elementu jeśli istnieje
	//przeszukiwanie za pomocą interpolacji
	public int szukaj(T x) {
	    if (rozmiar == 0) return -1;

	    int low = 0, high = rozmiar - 1;

	    while (low <= high && set[low].compareTo(x) <= 0 && set[high].compareTo(x) >= 0) {
	        int pos = low + ((x.compareTo(set[low]) * (high - low)) / (set[high].compareTo(set[low])));

	        if (set[pos].compareTo(x) == 0) return pos;
	        if (set[pos].compareTo(x) < 0) low = pos + 1;
	        else high = pos - 1;
	    }

	    return -1;
	}
	
	//usuwa element of wskazanej wartości jeśli istnieje
	public void usunElement(T x) {
		int i = szukaj(x);
		if (i == -1) {
			return;
		}
		for (int j = i; j < rozmiar-1; j++) {
			set[j] = set[j+1];
		}
		rozmiar--;
	}
	
	//dodaje elementy z innego zbioru
	public void dodajElementy(Set<T> S) throws Exception {
		//kopia S
		Set<T> temp = new Set<>(S.pojemnosc);
		for (int i = 0; i < S.rozmiar; i++) {
	        temp.dodajElement(S.set[i]);
	    }
		temp.odejmijElementy(this);
		
		//operujemy na temp aby nie modyfikować S
	    if (rozmiar + temp.rozmiar > pojemnosc) {
	        throw new Exception("Zbyt mała pojemnosc");
	    }
	    for (int i = 0; i < temp.rozmiar; i++) {
	    	try {
		        dodajElement(temp.set[i]);
	    	} catch (Exception e) {}; 
	    	//możemy zignorować wyjątek dodania istniejącego elementu, ponieważ oba zbiory są już rozdzielne więc nigdy nie wystąpi
	    }
	}
	
	//odejmuje elemmentu wspólne z innego zbioru
	public void odejmijElementy(Set<T> S) {
		for (int i = 0; i < S.rozmiar; i++) {
			usunElement(S.set[i]);
		}
	}
	
	public void przeciecie(Set<T> S) {
	    for (int i = rozmiar - 1; i >= 0; i--) {
	        if (S.szukaj(set[i]) == -1) {
	            usunElement(set[i]);
	        }
	    }
	}
	
	public String toString() {
		String s = "[";
		for (int i = 0; i <= rozmiar-2; i++) {
			s += set[i] + ", ";
		}
		if (rozmiar >= 1) {
			s += set[rozmiar-1];
		}
		s += "]";
		return s;
	}
	
}
