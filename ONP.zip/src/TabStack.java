public class TabStack {
    private final int MAX_SIZE = 20; // Maksymalny rozmiar stosu
    private String[] stack = new String[MAX_SIZE];
    private int size = 0;

    /**
     * Metoda zdejmująca wartość ze stosu
     * @return wartość z góry stosu
     */
    public String pop()
    {
        if (size <= 0) {
            throw new IllegalStateException("Stos jest pusty!");
        }
        size--;
        return stack[size];
    }

    /**
     * Metoda dokładająca na stos
     * @param a - wartość dokładana do stosu
     */
    public void push(String a) {
        if (size >= MAX_SIZE) {
            throw new StackOverflowError("Stos jest pełny! Nie można dodać więcej elementów.");
        }
        stack[size] = a;
        size++;
    }

    /**
     * Metoda zwraca tekstową reprezentację stosu
     */
    public String toString() {
        StringBuilder tmp = new StringBuilder();
        for (int i = 0; i < size; i++) {
            tmp.append(stack[i]).append(" ");
        }
        return tmp.toString();
    }

    /**
     * Metoda zwraca rozmiar stosu
     * @return size - rozmiar stosu
     */
    public int getSize() {
        return size;
    }

    /**
     * Ustawia wartość stosu (tylko dla debugowania, należy używać ostrożnie)
     * @param i nowy rozmiar stosu
     */
    public void setSize(int i) {
        if (i < 0 || i > MAX_SIZE) {
            throw new IllegalArgumentException("Niepoprawny rozmiar stosu max to 20!");
        }
        size = i;
    }

    /**
     * Metoda zwraca wartość z określonej pozycji stosu
     * @param i pozycja parametru do zobaczenia
     * @return wartość stosu
     */
    public String showValue(int i) {
        if (i < 0 || i >= size) {
            throw new IndexOutOfBoundsException("Nieprawidłowy indeks: " + i);
        }
        return stack[i];
    }
}