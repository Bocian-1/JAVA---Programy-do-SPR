import java.util.Stack;
public class ONP
{
    private TabStack stack = new TabStack();

    boolean czyPoprawneRownanie(String rownanie)
    {
        return rownanie.endsWith("=");
    }
    private int factorial(int n) {
        int wynik = 1;
        for (int i = 2; i <= n; i++) {
            wynik *= i;
        }
        return wynik;
    }
    public String obliczOnp(String rownanie) {

        try
        {
            if (!czyPoprawneRownanie(rownanie))
            {
                throw new IllegalStateException("Równanie w złej formie!");
            }
        }
        catch(IllegalStateException e)
        {
            return "Błąd: " + e.getMessage();
        }

        stack.setSize(0);
        String wynik = "";
        Double a, b;

        try {
            for (int i = 0; i < rownanie.length(); i++) {
                char znak = rownanie.charAt(i);

                if (Character.isDigit(znak)) {
                    wynik += znak;
                    if (i + 1 >= rownanie.length() || !Character.isDigit(rownanie.charAt(i + 1))) {
                        stack.push(wynik);
                        wynik = "";
                    }
                } else if (znak == '=')
                {
                    return stack.pop();
                } else if (znak != ' ')
                {
                    if (znak == '!')
                    {
                        a = Double.parseDouble(stack.pop());
                        if (a < 0) throw new ArithmeticException("silnia z liczby ujemnej!");
                        stack.push(factorial(a.intValue()) + "");
                    } else if (znak == '#')
                    {
                        a = Double.parseDouble(stack.pop());
                        if (a < 0) throw new ArithmeticException("pierwiastek z liczby ujemnej!");
                        stack.push(Math.sqrt(a) + "");
                    } else
                    {
                        b = Double.parseDouble(stack.pop());
                        a = Double.parseDouble(stack.pop());

                        switch (znak)
                        {
                            case '+': stack.push((a + b) + ""); break;
                            case '-': stack.push((a - b) + ""); break;
                            case 'x': case '*': stack.push((a * b) + ""); break;
                            case '/':
                                if (b == 0) throw new ArithmeticException("dzielenie przez zero!");
                                stack.push((a / b) + "");
                                break;
                            case '^': stack.push(Math.pow(a, b) + ""); break;
                            case '%':
                                if (b == 0) throw new ArithmeticException("modulo przez zero!");
                                stack.push((a % b) + "");
                                break;
                            default:
                            {
                                throw new IllegalArgumentException("Nieznany operator: " + znak);
                            }

                        }
                    }
                }
            }
        } catch (Exception e) {
            return "Błąd: " + e.getMessage();
        }

        return "0.0";
    }

    public String przeksztalcNaOnp(String rownanie) {
        if (!czyPoprawneRownanie(rownanie)) return "null";

        Stack<String> opStack = new Stack<>();
        StringBuilder wynik = new StringBuilder();

        for (int i = 0; i < rownanie.length(); i++) {
            char c = rownanie.charAt(i);
            if (Character.isDigit(c)) {
                wynik.append(c);
                if (i + 1 == rownanie.length() || !Character.isDigit(rownanie.charAt(i + 1))) {
                    wynik.append(" ");
                }
            } else {
                switch (c) {
                    case '+': case '-':
                        while (!opStack.isEmpty() && !opStack.peek().equals("(")) {
                            wynik.append(opStack.pop()).append(" ");
                        }
                        opStack.push(String.valueOf(c));
                        break;
                    case '*': case '/': case '%':
                        while (!opStack.isEmpty() && (opStack.peek().equals("*") || opStack.peek().equals("/") || opStack.peek().equals("%"))) {
                            wynik.append(opStack.pop()).append(" ");
                        }
                        opStack.push(String.valueOf(c));
                        break;
                    case '^':
                        while (!opStack.isEmpty() && opStack.peek().equals("^")) {
                            wynik.append(opStack.pop()).append(" ");
                        }
                        opStack.push(String.valueOf(c));
                        break;
                    case '#': case '!':
                        opStack.push(String.valueOf(c));
                        break;
                    case '(':
                        opStack.push(String.valueOf(c));
                        break;
                    case ')':
                        while (!opStack.isEmpty() && !opStack.peek().equals("(")) {
                            wynik.append(opStack.pop()).append(" ");
                        }
                        opStack.pop();
                        break;
                    case '=':
                        while (!opStack.isEmpty()) {
                            wynik.append(opStack.pop()).append(" ");
                        }
                        wynik.append("=");
                        break;
                }
            }
        }
        return wynik.toString();
    }


}