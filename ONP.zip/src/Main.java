public class Main
{
    public static void main(String[] args)
    {

        String[] tests =
                {
                        "(2+3)! =",
                        "(2+3)*(6-2)^2= 2 3 + 6 2 - 2 ^ * =",
                        "#25 =",
                        "27%4 =",
                        "25/0 =",
                        "25%0 =",
                        "#(2-5) =",
                        "2+2+2+2"
                };
        ONP onp = new ONP();
        for(String test : tests)
        {
            System.out.print(test + " ");
            String rownanieOnp = onp.przeksztalcNaOnp(test);
            System.out.print(rownanieOnp);
            String wynik = onp.obliczOnp(rownanieOnp);
            System.out.println(" " + wynik);
        }

    }
}