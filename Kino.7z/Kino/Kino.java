import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;
import com.thoughtworks.xstream.security.AnyTypePermission;

import java.io.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.ArrayList;

public class Kino {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        // Tworzenie seansów
        Seans seans1 = new Seans("Avatar 2", LocalDate.of(2025, 4, 10), LocalTime.of(18, 30), "14+", 10, 20);
        Seans seans2 = new Seans("Król Lew", LocalDate.of(2025, 4, 11), LocalTime.of(15, 00), "12+", 10, 20);
        Seans seans3 = new Seans("Spider-Man", LocalDate.of(2025, 4, 12), LocalTime.of(20, 00), "10+", 10, 20);

        // Tworzenie klientów
        Klient klient1 = new Klient("Kowalski", "Jan", "jan.kowalski@gmail.com", "600123456");
        Klient klient2 = new Klient("Nowak", "Anna", "anna.nowak@hotmail.com", "600987654");
        Klient klient3 = new Klient("Wiśniewski", "Marek", "marek.wisniewski@wp.pl", "601234567");
        Klient klient4 = new Klient("Zielińska", "Katarzyna", "katarzyna.zielinska@o2.pl", "602345678");

        // Rezerwacja miejsc
        rezerwujMiejsce(seans1, klient1, 'A', 1);  // Jan Kowalski
        rezerwujMiejsce(seans1, klient2, 'B', 5);  // Anna Nowak
        rezerwujMiejsce(seans2, klient3, 'C', 3);  // Marek Wiśniewski
        rezerwujMiejsce(seans3, klient4, 'D', 7);  // Katarzyna Zielińska
        rezerwujMiejsce(seans1, klient1, 'A', 2);  // Jan Kowalski ponownie

        // Zapis do pliku
        try (ObjectOutputStream wy = new ObjectOutputStream(new FileOutputStream(".\\seanse.dat"))) {
            wy.writeObject(seans1);
            wy.writeObject(seans2);
            wy.writeObject(seans3);
        }

        // Zapis klientów do pliku XML
        arrayListKlientToXml(new ArrayList<>(List.of(klient1, klient2, klient3, klient4)), ".\\klienci.xml");

        // Odczyt
        try (ObjectInputStream we = new ObjectInputStream(new FileInputStream(".\\seanse.dat"))) {
            Seans s1 = (Seans) we.readObject();
            Seans s2 = (Seans) we.readObject();
            Seans s3 = (Seans) we.readObject();
            System.out.println("Seanse po odczycie:");
            System.out.println(s1);
            System.out.println(s2);
            System.out.println(s3);
        }

        ArrayList<Klient> klienci = xmlToArrayListKlient(".\\klienci.xml");
        System.out.println("\nKlienci po odczycie:");
        for (Klient klient : klienci) {
            System.out.println(klient);
        }
    }

    public static void rezerwujMiejsce(Seans seans, Klient klient, char rzad, int miejsce) {
        if (seans.sala.get(rzad).get(miejsce)) {
            System.out.println("Miejsce " + rzad + miejsce + " jest zajęte");
            return;
        }
        seans.zajmijMiejsce(rzad, miejsce);
        klient.dodajRezerwacje(seans.tytul, rzad, miejsce);
        System.out.println("Rezerwacja miejsca " + rzad + miejsce + " dla klienta: " + klient.imie + " " + klient.nazwisko);
    }

    public static void arrayListKlientToXml(ArrayList<Klient> p, String filename) {
        if (filename != null) {
            try (BufferedWriter out = new BufferedWriter(new FileWriter(filename))) {
                XStream mapping = new XStream(new DomDriver());
                String xml = mapping.toXML(p);
                out.write(xml);
                System.out.println("Klienci zapisani do pliku -> " + filename);
            } catch (IOException e) {
                System.err.println("Błąd zapisu do pliku: " + e.getMessage());
            }
        }
    }

    public static ArrayList<Klient> xmlToArrayListKlient(String filename) {
        String xml = "";
        String strLine = "";
        if (filename != null) {
            try (BufferedReader in = new BufferedReader(new FileReader(filename))) {
                while ((strLine = in.readLine()) != null) {
                    xml = xml + strLine + "\n";
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        XStream xstream = new XStream(new DomDriver());
        xstream.addPermission(AnyTypePermission.ANY);
        return (ArrayList<Klient>) xstream.fromXML(xml);
    }
}

