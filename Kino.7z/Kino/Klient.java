import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

public class Klient implements Serializable {
    String nazwisko;
    String imie;
    String mail;
    String telefon;
    HashMap<String, HashMap<Character, ArrayList<Integer>>> rezerwacje;

    public Klient(String nazwisko, String imie, String mail, String telefon) {
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.mail = mail;
        this.telefon = telefon;
        this.rezerwacje = new HashMap<>();
    }

    @Override
    public String toString() {
        return "Klient:\nImię: " + imie + " Nazwisko: " + nazwisko + " Mail: " + mail + " Telefon: " + telefon + " Rezerwacje: " + rezerwacje;
    }

    public void dodajRezerwacje(String seans, char rzad, int miejsce) {
        if (rezerwacje.containsKey(seans)) {
            if (rezerwacje.get(seans).containsKey(rzad)) {
                if (!rezerwacje.get(seans).get(rzad).contains(miejsce)) {
                    rezerwacje.get(seans).get(rzad).add(miejsce);
                }
                return;
            }
            ArrayList<Integer> miejscaList = new ArrayList<>();
            miejscaList.add(miejsce);
            rezerwacje.get(seans).put(rzad, miejscaList);
            return;
        }
        HashMap<Character, ArrayList<Integer>> miejsca = new HashMap<>();
        ArrayList<Integer> miejscaList = new ArrayList<>();
        miejscaList.add(miejsce);
        miejsca.put(rzad, miejscaList);
        rezerwacje.put(seans, miejsca);
    }
}
