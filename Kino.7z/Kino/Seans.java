import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.HashMap;

public class Seans implements Serializable {
    String tytul;
    LocalDate dzien;
    LocalTime godzina;
    String ograniczenia;
    HashMap<Character, HashMap<Integer, Boolean>> sala;

    public Seans(String tytul, LocalDate dzien, LocalTime godzina, String ograniczenia, int rzedy, int miejsca) {
        this.tytul = tytul;
        this.dzien = dzien;
        this.godzina = godzina;
        this.ograniczenia = ograniczenia;
        this.sala = new HashMap<>();
        initializeSala(rzedy, miejsca);
    }

    private void initializeSala(int rzedy, int miejsca) {
        for (int i = 0; i < rzedy; i++) {
            HashMap<Integer, Boolean> miejscaMap = new HashMap<>();
            for (int j = 1; j <= miejsca; j++) {
                miejscaMap.put(j, false); // Miejsce początkowo dostępne
            }
            sala.put((char) ('A' + i), miejscaMap);
        }
    }

    @Override
    public String toString() {
        return "Seans: " + tytul + " Dzień: " + dzien + " Godzina: " + godzina + " Ograniczenia: " + ograniczenia + " Liczba miejsc: " + sala;
    }

    public void zajmijMiejsce(char rzad, int miejsce) {
        if (sala.get(rzad).get(miejsce)) {
            System.out.println("Miejsce " + rzad + miejsce + " jest zajęte");
            return;
        }
        sala.get(rzad).put(miejsce, true); // Zajmujemy miejsce
    }
}

